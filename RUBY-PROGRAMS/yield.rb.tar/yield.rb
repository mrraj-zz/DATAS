class Yield
	def siva
		p 'Hello World'
	end
end

y = Yield.new
y.siva
